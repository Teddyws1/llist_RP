/* =========================================================
   [INÍCIO] - PROCESSAMENTO DE DADOS E VARIÁVEIS GLOBAIS
   Descrição: Trata a string 'listText', cria os itens e
   gerencia o estado dos favoritos e aba atual.
   ========================================================= */
const animations = [...new Set(listText.split(',')
    .map(item => item.trim())
    .filter(item => item !== ''))]
    .sort((a, b) => a.localeCompare(undefined, { numeric: true, sensitivity: 'base' }));

let rawItems = listText.split(',').map(n => n.trim()).filter(n => n !== "");
let items = rawItems.map((name, i) => ({ name, id: i + 1 }));
let favorites = JSON.parse(localStorage.getItem('teddyFavs')) || [];
let currentTab = 'all';
let currentItem = null;
/* =========================================================
   [FIM] - PROCESSAMENTO DE DADOS
   ========================================================= */


/* =========================================================
   [INÍCIO] - FUNÇÃO DE RENDERIZAÇÃO (NÚCLEO DO SISTEMA)
   Descrição: Filtra, ordena, conta e desenha os cards na tela.
   ========================================================= */
function renderItems() {
    const grid = document.getElementById('gridItems');
    const search = document.getElementById('searchInput').value.toLowerCase();
    const sort = document.getElementById('sortOption').value;
    const clearAllBtn = document.getElementById('clearAllBtn');
    
    // Elemento do contador (certifique-se de ter o id="totalContador" no HTML)
    const contador = document.getElementById('totalContador');

    // Botão de limpar busca individual
    document.getElementById('clearBtn').style.display = search ? 'block' : 'none';
    
    // Escolha entre todos os itens ou favoritos
    let data = currentTab === 'all' ? [...items] : [...favorites];

    // Filtro de busca por nome ou ID
    if(search) {
        data = data.filter(i => 
            i.name.toLowerCase().includes(search) ||   
            i.id.toString() === search ||              
            i.id.toString().includes(search)           
        );
    }

    // Ordenação
    if(sort === 'alpha') {
        data.sort((a, b) => a.name.localeCompare(b.name));
    } else {
        data.sort((a, b) => b.id - a.id);
    }

    // ATUALIZAÇÃO DO CONTADOR
    if (contador) {
        contador.innerText = data.length;
    }

    // Botão de limpar todos os favoritos
    clearAllBtn.style.display = (currentTab === 'fav' && favorites.length > 0) ? 'block' : 'none';

    // Criação dos cards HTML
    grid.innerHTML = data.map(item => `
        <div class="card" onclick="openModal(${item.id})">
            ${currentTab === 'fav' ? `<i class="fas fa-trash-can delete-fav" onclick="event.stopPropagation(); removeFavorite(${item.id})"></i>` : ''}
            <strong>${item.name}</strong>
            <span>ID: ${item.id}</span>
        </div>
    `).join('');
}
/* =========================================================
   [FIM] - FUNÇÃO DE RENDERIZAÇÃO
   ========================================================= */


/* =========================================================
   [INÍCIO] - GERENCIAMENTO DE FAVORITOS
   Descrição: Funções para excluir um ou todos os favoritos.
   ========================================================= */
function clearAllFavorites() {
    if(confirm("Deseja limpar todos os favoritos?")) {
        favorites = [];
        localStorage.setItem('teddyFavs', JSON.stringify(favorites));
        renderItems();
    }
}

function removeFavorite(id) {
    favorites = favorites.filter(f => f.id !== id);
    localStorage.setItem('teddyFavs', JSON.stringify(favorites));
    renderItems();
}
/* =========================================================
   [FIM] - GERENCIAMENTO DE FAVORITOS
   ========================================================= */


/* =========================================================
   [INÍCIO] - CONTROLE DE MODAIS E SIDEBAR
   Descrição: Abre/fecha modais de detalhes e a barra lateral.
   ========================================================= */
function openTextModal(title, body) {
    document.getElementById('textModalTitle').innerText = title;
    document.getElementById('textModalBody').innerText = body;
    document.getElementById('textModal').style.display = 'flex';
}

function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('active'); }
function clearSearch() { document.getElementById('searchInput').value = ''; renderItems(); }

function openModal(id) {
    if (document.getElementById('sidebar').classList.contains('active')) return;
    currentItem = items.find(i => i.id === id);
    document.getElementById('modalTitle').innerText = currentItem.name;
    document.getElementById('modalID').innerText = `#${currentItem.id}`;
    document.getElementById('itemModal').style.display = 'flex';
    updateFavBtn();
}

function updateFavBtn() {
    const isFav = favorites.find(f => f.id === currentItem.id);
    const btn = document.getElementById('favBtn');
    btn.innerHTML = isFav ? '<i class="fas fa-star-half-alt"></i> Remover' : '<i class="fas fa-star"></i> Favoritar';
    btn.style.background = isFav ? "var(--danger)" : "var(--primary)";
}

document.getElementById('favBtn').onclick = () => {
    const idx = favorites.findIndex(f => f.id === currentItem.id);
    idx > -1 ? favorites.splice(idx, 1) : favorites.push(currentItem);
    localStorage.setItem('teddyFavs', JSON.stringify(favorites));
    updateFavBtn();
    renderItems();
};
/* =========================================================
   [FIM] - CONTROLE DE MODAIS
   ========================================================= */


/* =========================================================
   [INÍCIO] - UTILITÁRIOS E ESTÉTICA
   Descrição: Troca de abas, cópia de texto e temas.
   ========================================================= */
function switchTab(tab) {
    currentTab = tab;
    document.getElementById('tabAll').classList.toggle('active', tab === 'all');
    document.getElementById('tabFav').classList.toggle('active', tab === 'fav');
    renderItems();
}

function copyCommand() {
    navigator.clipboard.writeText(`/e ${currentItem.name}`);
    const btn = document.querySelector('.btn-copy');
    btn.innerHTML = '<i class="fas fa-check"></i> Pronto!';
    setTimeout(() => btn.innerHTML = '<i class="fas fa-copy"></i> Copiar', 1000);
}

function toggleTheme() { document.body.classList.toggle('light-theme'); }
/* =========================================================
   [FIM] - UTILITÁRIOS E ESTÉTICA
   ========================================================= */


/* =========================================================
   [INÍCIO] - EVENTOS DE JANELA E INSTALAÇÃO (PWA)
   Descrição: Cliques fora do modal e registro de Service Worker.
   ========================================================= */
window.onclick = (e) => {
    const sidebar = document.getElementById('sidebar');
    if (e.target.classList.contains('modal-overlay')) closeModal(e.target.id);
    if (sidebar && sidebar.classList.contains('active') && !sidebar.contains(e.target) && e.target !== document.getElementById('menuBtn') && !e.target.closest('.modal-overlay')) {
        toggleSidebar();
    }
}

document.getElementById('searchInput').oninput = renderItems;

if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').then(() => console.log("SW registrado!"));
}
/* =========================================================
   [FIM] - EVENTOS E INSTALAÇÃO
   ========================================================= */


/* =========================================================
   [INÍCIO] - SEGURANÇA E PROTEÇÃO
   Descrição: Bloqueios de clique direito, teclado, cópia e zoom.
   ========================================================= */
const CONFIG_PROTECAO = {
    bloquearCliqueDireito: false,
    bloquearTeclado: false,
    bloquearSelecao: false
};

(function() {
    document.addEventListener('contextmenu', (e) => CONFIG_PROTECAO.bloquearCliqueDireito && e.preventDefault());
    document.onselectstart = () => !CONFIG_PROTECAO.bloquearSelecao;
})();

// Bloqueio de Zoom Pinça e Ctrl+Scroll
document.addEventListener('touchstart', (e) => {
    if (e.touches.length > 1) e.preventDefault();
}, { passive: false });

document.addEventListener('wheel', (e) => {
    if (e.ctrlKey) e.preventDefault();
}, { passive: false });
/* =========================================================
   [FIM] - SEGURANÇA E PROTEÇÃO
   ========================================================= */


// Inicialização imediata ao carregar o script
renderItems();
// Faz o contador pulsar
const contador = document.getElementById('totalContador');
contador.classList.remove('bump');
void contador.offsetWidth; // Truque para resetar a animação
contador.classList.add('bump');

/* =========================================================
sobre atualização do sistema 
   ========================================================= */
  
   (function() {
    const startModal = () => {
        // Seletores por ID exclusivo
        const overlay = document.getElementById('un-modal-container');
        const openBtn = document.getElementById('un-btn-trigger');
        const closeBtn = document.getElementById('un-btn-confirm');
        const closeX = document.getElementById('un-close-x');

        if (!overlay || !openBtn) return;

        const open = () => { overlay.style.display = 'flex'; };
        const close = () => { overlay.style.display = 'none'; };

        openBtn.addEventListener('click', open);
        if (closeBtn) closeBtn.addEventListener('click', close);
        if (closeX) closeX.addEventListener('click', close);

        // Fecha se clicar fora do card
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) close();
        });
    };

    // Executa sem conflitos
    if (document.readyState === 'complete') {
        startModal();
    } else {
        window.addEventListener('load', startModal);
    }
})();
const modal = document.getElementById('un-modal-container');
const btnOpen = document.getElementById('un-btn-trigger');
const btnClose = document.getElementById('un-close-x');

// Abrir Modal
btnOpen.addEventListener('click', () => {
    modal.style.display = 'flex';
});

// Fechar ao clicar no X
btnClose.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Fechar ao clicar fora do card (no fundo cinza)
window.addEventListener('click', (event) => {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});

/* =========================================================
 sistema de bloqueio de Scroll 
   ========================================================= */
   
  
   
   /* =========================================================
fim sobre atualização do sisitema 
   ========================================================= */